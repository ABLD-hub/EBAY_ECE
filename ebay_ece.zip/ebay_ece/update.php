<?php 
session_start();?>


<?php
//echo "test";
//On initialise les différentes variables.
$database = "ebay_ece";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if ($db_found)
{
	$id_utilisateur=$_SESSION["id_utilisateur"];
	$id = isset($_POST["id"])? $_POST["id"] : "";
	if($id=="")
	{
		$id=$id_utilisateur;
	}
	echo "Mon id est :".$id;
	echo "Mon id utilisateur est :".$id_utilisateur;
//On accèdes aux données de l'utilisateur
	include 'acces_utilisateur.php';
	$email1 = isset($_POST["email"])? $_POST["email"] : "";
	echo "Mon email est :".$email1;
	$sqlcheck="SELECT * FROM utilisateur WHERE email='$email1';";
	echo $sqlcheck;
	$result=mysqli_query($db_handle, $sqlcheck);
	if(mysqli_num_rows($result)!=0)
	{
		if($_SESSION['type_utilisateur']=="admin")
			{

				include 'session.php';
				header('Location: admin.php');
				exit();
			}
			else
			{
				include 'session.php';
				echo $_SESSION['type_utilisateur']."="."admin";
				header('Location: Mon_Compte.php');
				exit();		
			}		
	}
	if($email1=="")
	{
		$email1=$email;
	}
	$nom_utilisateur1 = isset($_POST["nom_utilisateur"])? $_POST["nom_utilisateur"] : "";
	if($nom_utilisateur1=="")
	{
		$nom_utilisateur1=$nom_utilisateur1;
	}
	$prenom_utilisateur1= isset($_POST["prenom_utilisateur"])? $_POST["prenom_utilisateur"] : "";
	if($prenom_utilisateur1=="")
	{
		$prenom_utilisateur1=$prenom_utilisateur;
	}
	$pseudo1 = isset($_POST["pseudo"])? $_POST["pseudo"] : "";
	echo "Mon pseudo est :".$pseudo1;
	$sqlcheck="SELECT * FROM utilisateur WHERE  pseudo='$pseudo1';";
	echo $sqlcheck;
	$result=mysqli_query($db_handle, $sqlcheck);
	if(mysqli_num_rows($result)!=0)
	{
		if($_SESSION['type_utilisateur']=="admin")
			{
				include 'session.php';
				header('Location: admin.php');
				exit();
			}
			else
			{
				include 'session.php';
				echo"pseudo";
				header('Location: Mon_Compte.php');
				exit();		
			}		
	}
	if($pseudo1=="")
	{
		$pseudo1=$pseudo;
	}
	$mot_de_passe1 = isset($_POST["password"])? $_POST["password"] : "";
	if($mot_de_passe1=="")
	{
		$mot_de_passe1=$mot_de_passe;
	}
	$type_utilisateur1 = isset($_POST["type_utilisateur"])? $_POST["type_utilisateur"] : "";
	if($type_utilisateur1=="")
	{
		$type_utilisateur1=$type_utilisateur;
	}
	$adresse_ligne_11 = isset($_POST["adresse_ligne_1"])? $_POST["adresse_ligne_1"] : "";
	if($adresse_ligne_11=="")
	{
		$adresse_ligne_11=$adresse_ligne_1;
	}
	$adresse_ligne_21 = isset($_POST["adresse_ligne_2"])? $_POST["adresse_ligne_2"] : "";
	if($adresse_ligne_21=="")
	{
		$adresse_ligne_21=$adresse_ligne_2;
	}
	$adresse_ville1 = isset($_POST["adresse_ville"])? $_POST["adresse_ville"] : "";
	if($adresse_ville1=="")
	{
		$adresse_ville1=$adresse_ville;
	}
	$adresse_code_postal1 = isset($_POST["adresse_code_postal"])? $_POST["adresse_code_postal"] : "";
	if($adresse_code_postal1=="")
	{
		$adresse_code_postal1=$adresse_code_postal;
	}
	$adresse_pays1 = isset($_POST["adresse_pays"])? $_POST["adresse_pays"] : "";
	if($adresse_pays1=="")
	{
		$adresse_pays1=$adresse_pays;
	}
	$no_telephone1 = isset($_POST["no_telephone"])? $_POST["no_telephone"] : "";
	if($no_telephone1=="")
	{
		$no_telephone1=$no_telephone;
		if($no_telephone1=="")
		{
			$no_telephone1='NULL';
		}
	}
	$carte_type1 = isset($_POST["Choice"])? $_POST["Choice"] : "";
	if($carte_type1=="")
	{
		$carte_type1=$carte_type;
	}
	$carte_numero1 = isset($_POST["numero_carte"])? $_POST["numero_carte"] : "";
	if($carte_numero1=="")
	{
		$carte_numero1=$carte_numero;
	}
	$carte_nom1 = isset($_POST["carte_nom"])? $_POST["carte_nom"] : "";
	if($carte_nom1=="")
	{
		$carte_nom1=$carte_nom;
	}
	$carte_date_expiration1 = isset($_POST["carte_date_expiration"])? $_POST["carte_date_expiration"] : "";
	if($carte_date_expiration1=="")
	{
		$carte_date_expiration1=$carte_date_expiration;
		if($carte_date_expiration1=="")
		{
			$carte_date_expiration='NULL';
		}
	}
	$carte_code1 = isset($_POST["carte_code"])? $_POST["carte_code"] : "";
	if($carte_code1=="")
	{
		$carte_code1=$carte_code;
		if($carte_code1=="")
		{
			$carte_code1='NULL';
		}
	}


	if ($_POST["submit"])
	{
		/*On controlle le pseudo et l'adresse mail*/
			$sql ="UPDATE utilisateur SET email='$email1', nom_utilisateur='$nom_utilisateur1', prenom_utilisateur='$prenom_utilisateur1', pseudo='$pseudo1', mot_de_passe='$mot_de_passe1', type_utilisateur='$type_utilisateur1', adresse_ligne_1='$adresse_ligne_11', adresse_ligne_2='$adresse_ligne_21', adresse_ville='$adresse_ville1', adresse_pays='$adresse_pays1', no_telephone=$no_telephone1, carte_type='$carte_type1', carte_numero='$carte_numero1', carte_nom='$carte_nom1', carte_date_expiration='$carte_date_expiration1' WHERE id_utilisateur='$id'";
			$result = mysqli_query($db_handle, $sql);
							//Si ce n'est pas l'admin qui controlle le compte
			echo $sql;
			echo $id_utilisateur."==".$id;
			echo "Mon id utilisateur est :".$_SESSION["nom_utilisateur"];
			session_write_close();
			if($_SESSION['type_utilisateur']=="admin")
			{
				//include 'session.php';
				echo $_SESSION['nom_utilisateur'];
				header('Location: accueil.php');
				exit();
			}
			else
			{
				//include 'session.php';
				echo $_SESSION['nom_utilisateur'];
				header('Location: accueil.php');
				exit();		
			}							
	}
	else if($_POST["effacer"])
	{
		$sql= "DELETE FROM utilisateur WHERE id_utilisateur=$id;";
		echo $sql;
		$result = mysqli_query($db_handle, $sql);
		session_write_close();
		header('Location: admin.php');
		exit();
	}
}
else {  echo "Database not found";}
?>	
<?php /*****déclaration des variables******/
					$database="ebay_ece";
					//On veut tous les objets 
					$table1="objet";
					//du panier
					$table2="panier";
			      	$date_maintenant = date("Y-m-d");
			      	$date_facture = date("Y-m-d");
			      	$date_livraison =date('Y-m-d', strtotime($date_maintenant. ' + 5 days'));
			      	$id_facture=0;

			      	
        			/*****création d'une facture aujourd'hui******/
			      	$sql_creation_facture = "INSERT INTO facture(id_facture,id_acheteur,validation_transaction,date_facture,date_livraison) VALUES (NULL,$id_utilisateur,true,'$date_facture','$date_livraison');";
	              	mysqli_query($db_handle, $sql_creation_facture);
              	

	              	/*****récupération de l'id de la facture actuelle******/
					$sql_id_facture = "SELECT MAX(id_facture) FROM facture WHERE id_utilisateur='$id_utilisateur' AND date_facture='NULL' AND date_livraison = NULL;";
	              	$result_id_facture = mysqli_query($db_handle, $sql_id_facture);
	              	$row = $result->fetch_row();
	              	$id_facture=$row[0]+1;
	             
	              	/*****************recupere tout les objets dans le panier de l'utilisateur***********/
	              	$sql_requete_objet= "SELECT * FROM $table1 INNER JOIN $table2 ON $table1.id_objet = $table2.id_objet WHERE $table2.id_acheteur = $id_utilisateur AND $table1.vente_immediat=1 ";
					$result =mysqli_query($db_handle, $sql_requete_objet);
					while($data_recuperation_objet = mysqli_fetch_assoc($result))//==> nul s'il n'y a plus de ligne dans le tableau
			 		{	
			 			/*******on ajoute chacun des objets dans la facture******/
				      	$sql_ajout_facture = "INSERT INTO relation_facture_objet(id_relation,id_facture,id_objet,prix_objet) VALUES (NULL,$id_facture,".$data_recuperation_objet['id_objet'].",".$data_recuperation_objet['prix_initial_objet'].");";
	              		mysqli_query($db_handle, $sql_ajout_facture);

	              		$id_objet = $data_recuperation_objet['id_objet'];
	              		$sql = "UPDATE objet SET statut_vente='vendu' WHERE id_objet='$id_objet';";
	              	    mysqli_query($db_handle, $sql);

	              		$id_panier = $data_recuperation_objet['id_panier'];
				      	$sql= "DELETE FROM panier WHERE id_panier = '$id_panier';";
						mysqli_query($db_handle, $sql);
					}
?>
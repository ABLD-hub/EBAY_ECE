<?php

//Initialisation de la BDD
$database="ebay_ece";
$db_handle = mysqli_connect('localhost','root','');
$db_found = mysqli_select_db($db_handle,$database);
//Si celle-ci existe
if($db_found)
{ 
  echo "<div class='container-fluid' style='padding:10px;'>";
    //On choisit l'utilisateur correspondant à l'ID
    $sql = "SELECT * from utilisateur where (id_utilisateur='".$id."');";
    echo $sql;
  $result = mysqli_query($db_handle, $sql);
  //on accède aux données et récupère les données que l'utilisateur possède déjà pour remplir le form
  while($data = mysqli_fetch_assoc($result))//==> nul s'il n'y a plus de ligne dans le tableau
  {
              $nom_utilisateur=$data['nom_utilisateur'];
              $prenom_utilisateur=$data['prenom_utilisateur'];
              $pseudo=$data['pseudo'];
              $email=$data['email'];
              $mot_de_passe=$data['mot_de_passe'];
              $type_utilisateur=$data['type_utilisateur'];
              $lien_photo_utilisateur=$data['lien_photo_utilisateur'];
              $lien_photo_fond=$data['lien_photo_fond'];
              $adresse_ligne_1=$data['adresse_ligne_1'];
              $adresse_ligne_2=$data['adresse_ligne_2'];
              $adresse_ville=$data['adresse_ville'];
              $adresse_code_postal=$data['adresse_code_postal'];
              $adresse_pays=$data['adresse_pays'];
              $no_telephone=$data['no_telephone'];
              $carte_type=$data['carte_type'];
              $carte_numero=$data['carte_numero'];
              $carte_nom=$data['carte_nom'];
              $carte_date_expiration=$data['carte_date_expiration'];
              $carte_code=$data['cryptogramme'];
}
}
  else {  echo "Database not found";}

?>
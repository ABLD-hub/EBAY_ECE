<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Liste de vos commandes</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>

<body>

	<?php include 'navbar.html'; ?>
	

	<!------Recherche dans la base de donnée des objets achetés par cet utilisateur---->
	<?php
	$database="ebay_ece";
	$db_handle = mysqli_connect('localhost','root','');
	$db_found = mysqli_select_db($db_handle,$database);
	
	if($db_found)
	{ 
		$sql = "SELECT * from facture INNER JOIN relation_facture_objet ON facture.id_facture=relation_facture_objet.id_facture INNER JOIN objet ON relation_facture_objet.id_objet=objet.id_objet where id_acheteur=" . $_SESSION['id_utilisateur'] . ";";
		$result = mysqli_query($db_handle, $sql);
		$output ='<div  align="center">';
		$output.='<div id="fond_formulaire" class="col-sm-4" align="center">';
		$output.='<p style="font-size: 40px" align="center">Vos commandes réalisées</p><br>';
		$output.='<table style="padding: 60px;" align="center" >';
		$output.='<tr scope="alternance">
				  <th scope="col">No facture</th>
				  <th scope="col">Objet</th>
				  <th scope="col">Tarif</th>
				  <th scope="col">Total facture</th>
				  </tr>';
		echo $output;
		$sous_total=0.0;
		$no_facture_prec=0;
		$i=1;
		$total_general=0.0;
		while($data = mysqli_fetch_assoc($result))//==> nul s'il n'y a plus de ligne dans le tableau
		{ 
			echo "<tr scope='alternance'><td align='center'>" . $data['id_facture'] . "</td>";
			echo "<td>" . utf8_encode($data['nom_objet']) . "</td>";
			echo "<td align='right'>" . $data['prix_objet'] . " €</td>";
			echo "<td></td>";
			if ($data['id_facture']==$no_facture_prec){
				$sous_total = $sous_total + $data['prix_objet'];
				echo "<tr scope='alternance'><td></td><td align='right'><B>Total facture n°".$data['id_facture']." :</B></td><td></td><td align='right'><B>" . $sous_total . " €</B></td></tr>";	
				$i=0;				
			}
			else{
				$no_facture_prec=$data['id_facture'];
				$sous_total = $data['prix_objet'];		
				if ($i==1){
					echo "<tr scope='alternance'><td></td><td align='right'><B>Total facture n°".$data['id_facture']." :</B></td><td></td><td align='right'><B>" . $sous_total . " €</B></td></tr>";	
				}
			}
			$i++;
			$total_general = $total_general + + $data['prix_objet'];
			echo "</tr>";
		}
		echo "<tr><td></td><td align='right'><B>Total toutes factures :</td><td></td><td align='right'><B>" . $total_general . " €</B></td></tr>";	
		echo '</table>';
	}
	else
	{
		echo "database not found";
	}
	mysqli_close($db_handle);
	?>
				
				
				
	</div></div>
</body>
<?php include 'footer.html'; ?>
</html>
 

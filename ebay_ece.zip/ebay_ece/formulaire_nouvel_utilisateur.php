<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Création d'un compte utilisateur</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="check.js"></script>
</head>

<body id="formulaire_utilisateur">

	<?php include 'navbar.html'; ?>
	<div >
	<div  align="center">
		<div class="col-sm-4 page" align="center">
		<p style="font-size: 40px" align="center">Créer votre compte Ebay ECE</p>
		
		<!-- formulaire de récupération des informations utilisateur-->
		<form action="formulaire_nouvel_utilisateur.php" method="post" id="formulaire_nouvel_utilisateur" enctype="multipart/form-data">
			<table style="padding: 60px;" align="center" >
				<tr>
					<td>Nom :</td>
					<td><input type="text" class="form-control" name="nom" required></td>
				</tr>
				<tr>
					<td>Prénom :</td>
					<td><input type="text" class="form-control" name="prenom" required></textarea></td>
				</tr>
				<tr>
					<td>Pseudo :</td>
					<td><input type="text" class="form-control" name="pseudo" ></td>
				</tr>
				<tr>
					<td>Email :</td>
					<td><input type="email" class="form-control" name="email" required></td>
				</tr>
				
			</table>
			<br>
			<input type="submit" value="Valider" class="btn btn-primary" name="submit">
		</form>		
		<?php  		// envoi d'un mail de validation d'email
					// ajouter dans php.ini la ligne 'sendmail_path =C:\wamp\sendmail\sendmail.exe'
					// et configurer le fichier sendmail.ini dans la rubrique [sendmail]
			
			if(isset($_POST["submit"]))
			{
				// préparation des infos du mail
				$destinataire=isset($_POST["email"])? $_POST["email"]:"";
				//echo $destinataire;
				//$destinataire  = 'ece.ebay.2020@gmail.com';
				//$destinataire  = 'b.collot@neuf.fr';
				$expediteur = 'ece.ebay.2020@gmail.com';
				$objet = 'ECE Ebay - Validation de votre adresse mail';

				// préparation des données pour le contenu du mail
				$nom=isset($_POST["nom"])? $_POST["nom"]:"";
				$prenom=isset($_POST["prenom"])? $_POST["prenom"]:"";
				$pseudo=isset($_POST["pseudo"])? $_POST["pseudo"]:"";

				// création de l'en-tête du mail en HTML
				$headers  = 'MIME-Version: 1.0' . "\r\n"; // Version MIME
				$headers.= 'Content-type: text/html; charset="utf-8"'."\n"; // l'en-tete Content-type pour le format HTML  
				$headers.= 'Content-transfer-encoding: 8bit'."\n";   
				$headers.= 'From: "Ebay ECE "<ece.ebay.2020@gmail.com>'."\n"; //Expéditeur
				$message = '
				<html>
				<body>
				  <div align="left">
					Veuillez cliquez sur le lien ci-contre pour valider votre adresse email : 
					<a href="http://localhost/ebay_ece/formulaire_nouvel_utilisateur_suite.php?nom='.$nom.'&prenom='.$prenom.'&pseudo='.$pseudo.'&email='.$destinataire.'">Go</a>
				  </div>
				</body>
				</html>
				';
				
				// envoi du message
				if (mail($destinataire, $objet, $message, $headers)) // Envoi du message
				{
					echo '<br>Un message a été envoyé sur votre adresse mail. Veuillez suivre les instructions.<br>
					     Si vous ne recevez rien, vérifier votre adresse email et votre dossier courriers indésirables.';
				}
				else // Non envoyé
				{
					echo "Une erreur s'est produite. Vérifier vos informations.";
				}
			}
		?>
	</div></div></div>
</body>
<?php include 'footer.html'; ?>
</html>
 
